export type LoadingBehavior = {
    isLoading?: boolean;
    loadingType?: "spinner" | "ring";
    loadingText?: string;
  };