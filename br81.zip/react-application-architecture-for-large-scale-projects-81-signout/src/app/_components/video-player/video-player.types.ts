export type VideoProps = {
    src: string;
    poster?: string;
    className?: string;
}