import { SVGAttributes } from "react";

export type SvgIcon = SVGAttributes<SVGElement>;