import { Testimonial } from "@/types/testimonial.type"

export type TestimonialProps = {
    testimonial: Testimonial
}

export type TestimonialListProps = {
    testimonials: Testimonial[]
}