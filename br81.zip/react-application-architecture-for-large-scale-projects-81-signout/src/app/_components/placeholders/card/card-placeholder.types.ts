export type CardPlaceholderProps = {
    count?: number;
    className?: string;
  };