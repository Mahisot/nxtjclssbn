import { Tab } from "@/types/tab.type"

export type TabsProps = {
    tabs: Tab[]
}