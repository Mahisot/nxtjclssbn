import { Accordion } from "@/types/accordion"

export type AccordionProps = {
    data: Accordion[];
}