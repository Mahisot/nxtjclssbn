import { Notification} from "@/types/notification.interface";
export type NotificationProps = {};
export type NotificationToastProps = {
    notification: Notification;
  };