export type FeatureProps = {
    feature: Feature
}