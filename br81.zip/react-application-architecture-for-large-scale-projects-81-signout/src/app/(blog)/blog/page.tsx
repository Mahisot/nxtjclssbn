export default async function Blog() {
    return (
        <div className="text-5xl flex justify-center items-center w-full">
        <h1>This is blog page</h1>
        </div>
    )
}