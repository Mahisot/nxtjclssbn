export default async function NotFound() {
    return (
        <div className="text-5xl flex justify-center items-center w-full text-red-800">
        <h1>Not Found</h1>
        </div>
    )
}