export default async function courses() {
    return (
        <h1>This is student courses page</h1>
    )
}