
export default async function CourseDetails() {
    return (
        <div className="text-5xl flex justify-center items-center w-full">
        <h1>This is course details page</h1>
        </div>
    )
}