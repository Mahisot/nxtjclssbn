export default async function Profile() {
    return (
        <h1>This is student profile page</h1>
    )
}