'use client';
export default function Error() {
    return (
        <div className="text-5xl flex justify-center items-center w-full text-red-800">
        <h1>error</h1>
        </div>
    )
}