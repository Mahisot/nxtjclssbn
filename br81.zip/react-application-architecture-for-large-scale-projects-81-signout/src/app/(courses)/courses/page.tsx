export default async function Courses() {
    return (
        <div className="text-5xl flex justify-center items-center w-full">
        <h1>This is courses page</h1>
        </div>
    )
}