import { CourseChapter } from "@/types/course-chapter.interface";

export type CourseCurriculumProps = {
    data: CourseChapter[];
};