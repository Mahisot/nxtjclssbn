export type VerifyUserModel = {
    username: string;
    code: string;
}

export type SendAuthCode = {
    mobile: string;
}