import SignInForm from "./components/singin-form";

export default async function SignIn() {
    return  <SignInForm/>
}
