export enum CourseLevel {
    Beginners = 0,
    Intermediate,
    Advance
}