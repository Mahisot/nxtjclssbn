import React from "react";

export type Tab = {
    label: string;
    content: string | React.ReactNode
}