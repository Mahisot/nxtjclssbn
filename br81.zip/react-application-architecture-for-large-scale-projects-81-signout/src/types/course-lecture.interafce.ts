export interface CourseLecture {
    title: string;
    duration: number;
    description: string;
    videoSize: string;
}