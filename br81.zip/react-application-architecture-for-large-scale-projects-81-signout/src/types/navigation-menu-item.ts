type NavigationMenuItem = {
    title: string;
    href: string;
  };
  