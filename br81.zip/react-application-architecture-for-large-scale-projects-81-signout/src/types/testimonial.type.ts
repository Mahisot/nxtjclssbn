export type Testimonial = {
    image: string;
    name: string;
    skills: string;
    description: string;
  };