type Feature = {
    icon: string,
    title: string;
    description: string;
} 